package com.viettel.automl.repository;

import com.viettel.automl.entities.NotebookLogEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NotebookLogRepository extends JpaRepository<NotebookLogEntity, Long> {
}
