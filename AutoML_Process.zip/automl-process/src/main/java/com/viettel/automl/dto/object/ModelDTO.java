package com.viettel.automl.dto.object;

import java.sql.Time;
import java.time.Instant;
import java.util.List;

public class ModelDTO {
    private Long modelId;
    private String modelName;
    private Long modelMode;
    private Long algorithmType;
    private Long metrics;
    private boolean biggerIsBetter;
    private Long autoTurningType;
    private Long numberOfFolds;
    private Long maxTrialTime;
    private Long checkpointStep;
    private String optimizationAlgorithm;
    private Float dataSubsamplingRatio;
    private Long allowPersist;
    private String bestModelType;
    private String description;
    private String bestParameters;
    private Instant createTime;
    private String createUser;
    private Float ratio;
    private Float maxMissingRatioAllow;
    private Long maxDistinctValues;

//    private List<HistoryDTO> historyDTOS;
//    private List<SubModelDTO> subModelDTOS;
//    private List<ModelModelTypeMapDTO> modelModelTypeMapDTOS;
//    private ProjectDTO projectDTO;
//    private ConfigFlowDTO configFlowDTO;
//    private ConnectionDTO connectionDTO;


    public Long getModelId() {
        return modelId;
    }

    public void setModelId(Long modelId) {
        this.modelId = modelId;
    }

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public Long getModelMode() {
        return modelMode;
    }

    public void setModelMode(Long modelMode) {
        this.modelMode = modelMode;
    }

    public Long getAlgorithmType() {
        return algorithmType;
    }

    public void setAlgorithmType(Long algorithmType) {
        this.algorithmType = algorithmType;
    }

    public Long getMetrics() {
        return metrics;
    }

    public void setMetrics(Long metrics) {
        this.metrics = metrics;
    }

    public Float getRatio() {
        return ratio;
    }

    public void setRatio(Float ratio) {
        this.ratio = ratio;
    }

    public boolean isBiggerIsBetter() {
        return biggerIsBetter;
    }

    public void setBiggerIsBetter(boolean biggerIsBetter) {
        this.biggerIsBetter = biggerIsBetter;
    }

    public Long getAutoTurningType() {
        return autoTurningType;
    }

    public void setAutoTurningType(Long autoTurningType) {
        this.autoTurningType = autoTurningType;
    }

    public Long getNumberOfFolds() {
        return numberOfFolds;
    }

    public void setNumberOfFolds(Long numberOfFolds) {
        this.numberOfFolds = numberOfFolds;
    }

    public Long getMaxTrialTime() {
        return maxTrialTime;
    }

    public void setMaxTrialTime(Long maxTrialTime) {
        this.maxTrialTime = maxTrialTime;
    }

    public Long getCheckpointStep() {
        return checkpointStep;
    }

    public void setCheckpointStep(Long checkpointStep) {
        this.checkpointStep = checkpointStep;
    }

    public String getOptimizationAlgorithm() {
        return optimizationAlgorithm;
    }

    public void setOptimizationAlgorithm(String optimizationAlgorithm) {
        this.optimizationAlgorithm = optimizationAlgorithm;
    }

    public Float getDataSubsamplingRatio() {
        return dataSubsamplingRatio;
    }

    public void setDataSubsamplingRatio(Float dataSubsamplingRatio) {
        this.dataSubsamplingRatio = dataSubsamplingRatio;
    }

    public Long getAllowPersist() {
        return allowPersist;
    }

    public void setAllowPersist(Long allowPersist) {
        this.allowPersist = allowPersist;
    }

    public String getBestModelType() {
        return bestModelType;
    }

    public void setBestModelType(String bestModelType) {
        this.bestModelType = bestModelType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getBestParameters() {
        return bestParameters;
    }

    public void setBestParameters(String bestParameters) {
        this.bestParameters = bestParameters;
    }

    public Instant getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Instant createTime) {
        this.createTime = createTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Float getMaxMissingRatioAllow() {
        return maxMissingRatioAllow;
    }

    public void setMaxMissingRatioAllow(Float maxMissingRatioAllow) {
        this.maxMissingRatioAllow = maxMissingRatioAllow;
    }

    public Long getMaxDistinctValues() {
        return maxDistinctValues;
    }

    public void setMaxDistinctValues(Long maxDistinctValues) {
        this.maxDistinctValues = maxDistinctValues;
    }
}

