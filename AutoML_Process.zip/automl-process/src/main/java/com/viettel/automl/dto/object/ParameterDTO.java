package com.viettel.automl.dto.object;

public class ParameterDTO {
    private Long parameterId;
    private String parameterName;
    private Long parameterType;
    private Long subModelId;
    private Long modelTypeId;
    private Long dataType;

    private Float min;
    private Float max;
    private Long uniform;
    private Float step;
    private String parameterValue;

    public Long getParameterId() {
        return parameterId;
    }

    public void setParameterId(Long parameterId) {
        this.parameterId = parameterId;
    }

    public String getParameterName() {
        return parameterName;
    }

    public void setParameterName(String parameterName) {
        this.parameterName = parameterName;
    }

    public Long getParameterType() {
        return parameterType;
    }

    public void setParameterType(Long parameterType) {
        this.parameterType = parameterType;
    }

    public Long getSubModelId() {
        return subModelId;
    }

    public void setSubModelId(Long subModelId) {
        this.subModelId = subModelId;
    }

    public Long getModelTypeId() {
        return modelTypeId;
    }

    public void setModelTypeId(Long modelTypeId) {
        this.modelTypeId = modelTypeId;
    }

    public Long getDataType() {
        return dataType;
    }

    public void setDataType(Long dataType) {
        this.dataType = dataType;
    }

    public Float getMin() {
        return min;
    }

    public void setMin(Float min) {
        this.min = min;
    }

    public Float getMax() {
        return max;
    }

    public void setMax(Float max) {
        this.max = max;
    }

    public Long getUniform() {
        return uniform;
    }

    public void setUniform(Long uniform) {
        this.uniform = uniform;
    }

    public Float getStep() {
        return step;
    }

    public void setStep(Float step) {
        this.step = step;
    }

    public String getParameterValue() {
        return parameterValue;
    }

    public void setParameterValue(String parameterValue) {
        this.parameterValue = parameterValue;
    }
}

