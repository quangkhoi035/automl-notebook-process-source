package com.viettel.automl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.viettel.automl.dto.object.NotebookDTO;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class AutoMLProcessApplication {
    public static void main(String[] args) {
        SpringApplication.run(AutoMLProcessApplication.class, args);
    }
}
