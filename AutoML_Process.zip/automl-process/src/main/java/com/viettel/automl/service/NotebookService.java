package com.viettel.automl.service;

import com.viettel.automl.dto.object.NotebookDTO;

public interface NotebookService {
   NotebookDTO findByHistoryId(Long historyId);
}
