package com.viettel.automl.tasks;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.viettel.automl.config.ConfigInfo;
import com.viettel.automl.dto.object.*;
import com.viettel.automl.entities.*;
import com.viettel.automl.repository.*;
import com.viettel.automl.service.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Service
public class HistoryTask extends BaseService {

    private final HistoryRepository historyRepository;
    @Autowired
    private ConfigFlowRepository configFlowRepository;
    @Autowired
    private ParameterInUseRepository parameterInUseRepository;
    @Autowired
    private ModelTypeRepository modelTypeRepository;
    @Autowired
    private MetricRepository metricRepository;
    @Autowired
    private ProjectRepository projectRepository;
    @Autowired
    private ModelRepository modelRepository;
    @Autowired
    private NotebookLogRepository notebookLogRepository;
    @Autowired
    private ConfigInfo configInfo;
    private ExecutorService executor;

    public HistoryTask(HistoryRepository historyRepository) {
        this.historyRepository = historyRepository;
        this.executor = Executors.newFixedThreadPool(10);
    }

    @Scheduled(cron = "${cron}")
    public void runProcess() {
        // Load va add list history vao queue của ExecutorService
        try {
            List<HistoryDTO> listHistory = this.getListHistory();
            listHistory.forEach(historyDTO -> {
                Runnable worker = new ZeTask(historyRepository, notebookLogRepository, historyDTO, configInfo);

                //Cap nhat trang thai History thanh pending
                updateCurrentStatusHistory(historyDTO, 2l);
                executor.execute(worker);
            });
        } catch(Exception e){

        }
    }

    private List<HistoryDTO> getListHistory() {
        List<HistoryEntity> entities = historyRepository.findByCurrentStatus(0l);
        List<HistoryDTO> dtos = super.mapList(entities, HistoryDTO.class);
        dtos.forEach(dto -> {
            ConfigFlowEntity configFlowEntity = configFlowRepository.findById(dto.getConfigFlowId())
                    .orElseThrow(() -> new RuntimeException("Resource not found"));
            dto.setConfigFlowDTO(super.map(configFlowEntity, ConfigFlowDTO.class));

            ModelEntity modelEntity = modelRepository.findById(dto.getModelId())
                    .orElseThrow(() -> new RuntimeException("Resource not found"));
            dto.setModelDTO(super.map(modelEntity, ModelDTO.class));

            List<ParameterInUseEntity> parameterInUseEntities = parameterInUseRepository
                    .findByConfigFlowId(configFlowEntity.getConfigFlowId());
            if(parameterInUseEntities.size() == 0) {
                throw new RuntimeException("Resource not found");
            }
            dto.setParameterInUseDTOS(super.mapList(parameterInUseEntities, ParameterInUseDTO.class));

            ModelTypeEntity modelTypeEntity = modelTypeRepository.findById(parameterInUseEntities.get(0).getModelTypeId())
                    .orElseThrow(() -> new RuntimeException("Resource not found"));

            dto.setModelTypeDTO(super.map(modelTypeEntity, ModelTypeDTO.class));

            ProjectEntity projectEntity = projectRepository.findById(configFlowEntity.getProjectId())
                    .orElseThrow(() -> new RuntimeException("Resource not found"));

            MetricEntity metricEntity = metricRepository.findById(modelEntity.getMetrics())
                    .orElseThrow(() -> new RuntimeException("Resource not found"));

            NotebookDTO notebookDTO = new NotebookDTO();
            notebookDTO.setProject(projectEntity.getProjectName());
            notebookDTO.setModel_name(modelEntity.getModelName());
            notebookDTO.setTrain_table(configFlowEntity.getTrainingTable());
            notebookDTO.setValid_table(configFlowEntity.getValidationTable());
            notebookDTO.setTest_table(configFlowEntity.getTestingTable());
            notebookDTO.setFeatures_columns(configFlowEntity.getFeatureColumns());
            notebookDTO.setLabel_column(configFlowEntity.getLabelColumn());
            notebookDTO.setMode(modelEntity.getModelMode() == 0 ? "auto" : "manual");
            notebookDTO.setConfiguration(modelEntity.getAlgorithmType() == 0 ? "classification" : "regression");
            if (modelEntity.getAutoTurningType().equals(1L)) {
                notebookDTO.setAuto_tuning_type("hold_out");
            } else if (modelEntity.getAutoTurningType().equals(2L)) {
                notebookDTO.setAuto_tuning_type("random_split");
            } else {
                notebookDTO.setAuto_tuning_type("cross_validation");
            }
            notebookDTO.setFeature_max_missing_ratio_allow(modelEntity.getMaxMissingRatioAllow());
            notebookDTO.setFeature_max_distinct_values(modelEntity.getMaxDistinctValues());
            notebookDTO.setMetric(metricEntity.getName());
            notebookDTO.setMax_trials(modelEntity.getMaxTrialTime());
            notebookDTO.setCheckpoint_steps(modelEntity.getCheckpointStep());
            notebookDTO.setData_subsampling_ratio(modelEntity.getDataSubsamplingRatio());
            notebookDTO.setAllow_persist(modelEntity.getAllowPersist().equals(1L));
            notebookDTO.setSearch_algorithm(modelEntity.getOptimizationAlgorithm());
            try {
                notebookDTO.setSearch_space(this.createSearchSpace(parameterInUseEntities));
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
            notebookDTO.setTrain_ratio(modelEntity.getRatio());
            notebookDTO.setK_folds(modelEntity.getNumberOfFolds());

            dto.setNotebookDTO(notebookDTO);
        });

        return dtos;
    }

    private String createSearchSpace(List<ParameterInUseEntity> entities) throws JsonProcessingException {
        Set<Long> ids = new HashSet<>();
        entities.forEach(e -> {
            ids.add(e.getModelTypeId());
        });
        List<SearchSpaceDTO> dtos = new ArrayList<>();
        ids.forEach(id -> {
            ModelTypeEntity modelTypeEntity = modelTypeRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Resource not found"));

            SearchSpaceDTO dto = new SearchSpaceDTO();
            dto.setType(modelTypeEntity.getModelTypeName());
            Optional<ParameterInUseEntity> entityF = entities.stream()
                    .filter(e -> "featureSubsetStrategy".equals(e.getParameterName()))
                    .findFirst();
            entityF.ifPresent(e -> {
                String str = "hp.choice('" + dto.getType() + "',[";
                str += e.getParameterValue() + "])";
                dto.setFeatureSubsetStrategy(str);
            });

            Optional<ParameterInUseEntity> entityN = entities.stream()
                    .filter(e -> "numTrees".equals(e.getParameterName()))
                    .findFirst();
            entityN.ifPresent(e -> {
                String str = "";
                if(e.getUniform().equals(0L)) {
                    str += "hp.quniform('";
                } else {
                    str += "hp.qnormal('";
                }
                str += dto.getType() + "_numTrees',";
                str += e.getMin() + "," + e.getMax() + "," + e.getStep() + ")";
                dto.setNumTrees(str);
            });

            Optional<ParameterInUseEntity> entityMD = entities.stream()
                    .filter(e -> "maxDepth".equals(e.getParameterName()))
                    .findFirst();
            entityMD.ifPresent(e -> {
                String str = "";
                if(e.getUniform().equals(0L)) {
                    str += "hp.quniform('";
                } else {
                    str += "hp.qnormal('";
                }
                str += dto.getType() + "_maxDepth',";
                str += e.getMin() + "," + e.getMax() + "," + e.getStep() + ")";
                dto.setMaxDepth(str);
            });

            Optional<ParameterInUseEntity> entityMB = entities.stream()
                    .filter(e -> "maxBins".equals(e.getParameterName()))
                    .findFirst();
            entityMB.ifPresent(e -> {
                String str = "";
                if(e.getUniform().equals(0L)) {
                    str += "hp.quniform('";
                } else {
                    str += "hp.qnormal('";
                }
                str += dto.getType() + "_maxBins',";
                str += e.getMin() + "," + e.getMax() + "," + e.getStep() + ")";
                dto.setMaxBins(str);
            });

            Optional<ParameterInUseEntity> entityMI = entities.stream()
                    .filter(e -> "minInstancesPerNode".equals(e.getParameterName()))
                    .findFirst();
            entityMI.ifPresent(e -> {
                String str = "";
                if(e.getUniform().equals(0L)) {
                    str += "hp.quniform('";
                } else {
                    str += "hp.qnormal('";
                }
                str += dto.getType() + "_minInstancesPerNode',";
                str += e.getMin() + "," + e.getMax() + "," + e.getStep() + ")";
                dto.setMinInstancesPerNode(str);
            });

            Optional<ParameterInUseEntity> entityS = entities.stream()
                    .filter(e -> "subsamplingRate".equals(e.getParameterName()))
                    .findFirst();
            entityS.ifPresent(e -> {
                String str = "";
                if(e.getUniform().equals(0L)) {
                    str += "hp.uniform('";
                } else {
                    str += "hp.normal('";
                }
                str += dto.getType() + "_subsamplingRate',";
                str += e.getMin() + "," + e.getMax() + ")";
                dto.setSubsamplingRate(str);
            });

            Optional<ParameterInUseEntity> entityMIG = entities.stream()
                    .filter(e -> "minInfoGain".equals(e.getParameterName()))
                    .findFirst();
            entityMIG.ifPresent(e -> {
                String str = "";
                if(e.getUniform().equals(0L)) {
                    str += "hp.uniform('";
                } else {
                    str += "hp.normal('";
                }
                str += dto.getType() + "_minInfoGain',";
                str += e.getMin() + "," + e.getMax() + ")";
                dto.setMinInfoGain(str);
            });
            dtos.add(dto);
        });

        //to json
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        return ow.writeValueAsString(dtos);
    }

    private void updateCurrentStatusHistory(HistoryDTO dto, Long newStatus){
        HistoryEntity historyEntity = historyRepository.findById(dto.getHistoryId()).orElseThrow(
                () -> new RuntimeException("Resource not found")
        );
        historyEntity.setCurrentStatus(newStatus);
        historyRepository.save(historyEntity);
    }

}
