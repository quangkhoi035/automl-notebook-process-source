package com.viettel.automl.dto.response.noteinformation;

public class Result {
    private String code;
    private Msg[] msg;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Msg[] getMsg() {
        return msg;
    }

    public void setMsg(Msg[] msg) {
        this.msg = msg;
    }

    public Result() {
    }

    @Override
    public String toString() {
        String str = "{" +
                "code='" + code + '\'';
        if(this.msg != null && this.msg.length != 0){
            str+= "{" +
                    "msg='" + msg[0] + '\'' ;
        }
        str += '}';
        return str;
    }
}
