package com.viettel.automl.dto.object;

import java.time.Instant;
import java.util.List;

public class ProjectDTO {
    private Long projectId;
    private String projectName;
    private String description;
    private Instant createTime;
    private String createUser;

    //search model
    private String modelName;
    private String bestModelType;
    private Long modelMode;
    private String task;
    private Long modelType;

    private List<ConfigFlowDTO> configFlowDTOS;

    //    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private String createFrom;
    //    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private String createTo;

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Instant getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Instant createTime) {
        this.createTime = createTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public String getBestModelType() {
        return bestModelType;
    }

    public void setBestModelType(String bestModelType) {
        this.bestModelType = bestModelType;
    }

    public Long getModelMode() {
        return modelMode;
    }

    public void setModelMode(Long modelMode) {
        this.modelMode = modelMode;
    }

    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

    public Long getModelType() {
        return modelType;
    }

    public void setModelType(Long modelType) {
        this.modelType = modelType;
    }

    public List<ConfigFlowDTO> getConfigFlowDTOS() {
        return configFlowDTOS;
    }

    public void setConfigFlowDTOS(List<ConfigFlowDTO> configFlowDTOS) {
        this.configFlowDTOS = configFlowDTOS;
    }

    public String getCreateFrom() {
        return createFrom;
    }

    public void setCreateFrom(String createFrom) {
        this.createFrom = createFrom;
    }

    public String getCreateTo() {
        return createTo;
    }

    public void setCreateTo(String createTo) {
        this.createTo = createTo;
    }

    public ProjectDTO() {
    }

    public ProjectDTO(Long projectId, String projectName, String description, Instant createTime, String createUser) {
        this.projectId = projectId;
        this.projectName = projectName;
        this.description = description;
        this.createTime = createTime;
        this.createUser = createUser;
    }
}
