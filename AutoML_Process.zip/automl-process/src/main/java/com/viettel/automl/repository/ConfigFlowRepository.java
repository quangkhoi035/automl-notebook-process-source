package com.viettel.automl.repository;

import com.viettel.automl.entities.ConfigFlowEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ConfigFlowRepository extends JpaRepository<ConfigFlowEntity, Long> {
    Optional<ConfigFlowEntity> findByModelId(Long modelId);
}
