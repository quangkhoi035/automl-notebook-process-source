package com.viettel.automl.dto.object;

public class ModelTypeDTO {
    private Long modelTypeId;
    private String modelTypeName;
    private Long algorithmType;

    public Long getModelTypeId() {
        return modelTypeId;
    }

    public void setModelTypeId(Long modelTypeId) {
        this.modelTypeId = modelTypeId;
    }

    public String getModelTypeName() {
        return modelTypeName;
    }

    public void setModelTypeName(String modelTypeName) {
        this.modelTypeName = modelTypeName;
    }

    public Long getAlgorithmType() {
        return algorithmType;
    }

    public void setAlgorithmType(Long algorithmType) {
        this.algorithmType = algorithmType;
    }
}
