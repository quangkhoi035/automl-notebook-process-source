package com.viettel.automl.dto.response.noteinformation;

import java.util.List;

public class NoteInformationResponse {
    private int statusCode;
    private String status;
    private String message;
    private Body body;

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Body getBody() {
        return body;
    }

    public void setBody(Body body) {
        this.body = body;
    }

    public NoteInformationResponse() {
    }

    @Override
    public String toString() {
        return "NoteInformationResponse{" +
                "statusCode=" + statusCode + "\n" +
                ", status='" + status + '\'' + "\n" +
                ", message='" + message + '\'' + "\n" +
                ", body=" + body + "\n" +
                '}';
    }
}
