//package com.viettel.automl;
//
//import com.viettel.automl.dto.object.HistoryDTO;
//import org.apache.http.Header;
//import org.apache.http.NameValuePair;
//import org.apache.http.client.entity.UrlEncodedFormEntity;
//import org.apache.http.client.methods.CloseableHttpResponse;
//import org.apache.http.client.methods.HttpPost;
//import org.apache.http.client.methods.HttpUriRequest;
//import org.apache.http.client.methods.RequestBuilder;
//import org.apache.http.entity.ContentType;
//import org.apache.http.entity.StringEntity;
//import org.apache.http.impl.client.DefaultHttpClient;
//import org.apache.http.message.BasicNameValuePair;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.scheduling.annotation.Scheduled;
//
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.PriorityQueue;
//import java.util.Queue;
//
//@SuppressWarnings("deprecation")
//public class ProjectSchudele {
//    @Autowired
//    private static Queue<HistoryDTO> queue = new PriorityQueue<>();
//
//    @Scheduled(cron = "* */5 * * * *")
//    public static void runProcess() throws IOException {
//
//        // Load va add list history vao queue
//        List<HistoryDTO> listHistory = getListHistory();
//        queue.addAll(listHistory);
//
//        while (queue.size() >0){
//            HistoryDTO historyDTO = queue.poll();
//
//            runBusiness(historyDTO);
//        }
//
//    }
//
//    public static List<HistoryDTO> getListHistory() throws IOException {
//        // goi api cua hoa ma tra ve
//        return  new ArrayList<>();
//    }
//
//    public static void runBusiness(HistoryDTO historyDTO) {
//        // tu config_flow trong historyDTO, kiem tra cap ... Ung voi th nao thi clone notebook tuong ung
//        // cap nhat trang thai current_status cua history tuong ung ve runnig (la ...)
//        // run notebook vua clone ra
//        // voi kq tr ve cua run notebook
//        // cap nhat trang thai current_status cua history tuong ung ve error hay done(la ...) va mot so truong khac
//        // tu kequa tra ve
//    }
//
//
//    public static void startRunNoteBook(DefaultHttpClient httpclient) throws IOException {
//        String jSessionId = zeppelinApiLogin("admin", "123456", httpclient);
//        zeppelinRunNotebookWithParam(jSessionId, httpclient);
//    }
//
//    private static String zeppelinApiLogin(String username, String password, DefaultHttpClient httpclient) throws IOException {
//        String urlLogin = "http://128.199.239.168:8089/api/login";
//        HttpPost postRequest = new HttpPost(urlLogin);
//        List<NameValuePair> formparams = new ArrayList<>();
//        formparams.add(new BasicNameValuePair("userName", username));
//        formparams.add(new BasicNameValuePair("password", password));
//        postRequest.setEntity(new UrlEncodedFormEntity(formparams, "UTF-8"));
//        CloseableHttpResponse response = httpclient.execute(postRequest);
//        System.out.println(response);
//        response.close();
//        return parseSessionID(response);
//    }
//
//    public static void zeppelinRunNotebookWithParam(String jSessionId, DefaultHttpClient httpclient) throws IOException {
//        HttpUriRequest request = RequestBuilder.create("POST")
//                .setUri("http://128.199.239.168:8089/api/notebook/job/2FYWZXAWK")
//                .setHeader("JSESSIONID", jSessionId)
//                .setEntity(new StringEntity("{\n" +
//                        "  \"params\": {\n" +
//                        "  \"name\": \"Tran Quang Khoi 999\"\n" +
//                        "  }\n" +
//                        "}", ContentType.APPLICATION_JSON))
//                .build();
//
//        CloseableHttpResponse response = httpclient.execute(request);
//        System.out.println(response);
//        response.close();
//        httpclient.close();
//    }
//
//    public static void zeppelinApiCreateNotebook(String jSessionId) throws IOException {
//        DefaultHttpClient httpclient = new DefaultHttpClient();
//
//        HttpUriRequest request = RequestBuilder.create("POST")
//                .setUri("http://128.199.239.168:8089/api/notebook")
//                .setHeader("JSESSIONID", jSessionId)
//                .setEntity(new StringEntity("{\"name\": \"Test create note 999\"}", ContentType.APPLICATION_JSON))
//                .build();
//
//        CloseableHttpResponse response1 = httpclient.execute(request);
//        System.out.println(response1);
//        response1.close();
//        httpclient.close();
//    }
//
//    private static String parseSessionID(CloseableHttpResponse response) {
//        String nid = "";
//        try {
//            Header[] header = response.getAllHeaders();
//            for (int i = 0; i < header.length; i++) {
//                String value = header[i].getValue();
//                if (value.contains("JSESSIONID")) {
//                    int index = value.indexOf("JSESSIONID =");
//                    int endIndex = value.indexOf(";", index);
//                    String sessionID = value.substring(index + "JSESSIONID =".length(), endIndex);
//                    nid = sessionID;
//
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return nid;
//
//    }
//
//    class ConfigFlow {
//        String name;
//    }
//}
