package com.viettel.automl.dto.object;

import java.time.Instant;
import java.util.List;

public class ConfigFlowDTO {
    private Long configFlowId;
    private Long projectId;
    private Long modelId;
    private String runNote;
    private String task;
    private String schedule;
    private String outputTableName;
    private Long outputTableMode;
    private String outputTablePartition;
    private String location;
    private Long connectionId;
    private String parameterString;
    private String trainingTable;
    private String validationTable;
    private String testingTable;
    private String inferenceTable;
    private String featureColumns;
    private String labelColumn;
    private String outputColumns;
    private Instant createTime;
    private String createUser;
    private Long runType;

    private List<ParameterDTO> parameterDTOS;
    private ModelDTO modelDTO;
    private List<String> featureColumnArr;
    private List<String> outputColumnArr;

    public Long getConfigFlowId() {
        return configFlowId;
    }

    public void setConfigFlowId(Long configFlowId) {
        this.configFlowId = configFlowId;
    }

    public Long getProjectId() {
        return projectId;
    }

    public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }

    public Long getModelId() {
        return modelId;
    }

    public void setModelId(Long modelId) {
        this.modelId = modelId;
    }

    public String getRunNote() {
        return runNote;
    }

    public void setRunNote(String runNote) {
        this.runNote = runNote;
    }

    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

    public String getSchedule() {
        return schedule;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }

    public String getOutputTableName() {
        return outputTableName;
    }

    public void setOutputTableName(String outputTableName) {
        this.outputTableName = outputTableName;
    }

    public Long getOutputTableMode() {
        return outputTableMode;
    }

    public void setOutputTableMode(Long outputTableMode) {
        this.outputTableMode = outputTableMode;
    }

    public String getOutputTablePartition() {
        return outputTablePartition;
    }

    public void setOutputTablePartition(String outputTablePartition) {
        this.outputTablePartition = outputTablePartition;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Long getConnectionId() {
        return connectionId;
    }

    public void setConnectionId(Long connectionId) {
        this.connectionId = connectionId;
    }

    public String getParameterString() {
        return parameterString;
    }

    public void setParameterString(String parameterString) {
        this.parameterString = parameterString;
    }

    public String getTrainingTable() {
        return trainingTable;
    }

    public void setTrainingTable(String trainingTable) {
        this.trainingTable = trainingTable;
    }

    public String getValidationTable() {
        return validationTable;
    }

    public void setValidationTable(String validationTable) {
        this.validationTable = validationTable;
    }

    public String getTestingTable() {
        return testingTable;
    }

    public void setTestingTable(String testingTable) {
        this.testingTable = testingTable;
    }

    public String getInferenceTable() {
        return inferenceTable;
    }

    public void setInferenceTable(String inferenceTable) {
        this.inferenceTable = inferenceTable;
    }

    public String getFeatureColumns() {
        return featureColumns;
    }

    public void setFeatureColumns(String featureColumns) {
        this.featureColumns = featureColumns;
    }

    public String getLabelColumn() {
        return labelColumn;
    }

    public void setLabelColumn(String labelColumn) {
        this.labelColumn = labelColumn;
    }

    public String getOutputColumns() {
        return outputColumns;
    }

    public void setOutputColumns(String outputColumns) {
        this.outputColumns = outputColumns;
    }

    public Instant getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Instant createTime) {
        this.createTime = createTime;
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    public Long getRunType() {
        return runType;
    }

    public void setRunType(Long runType) {
        this.runType = runType;
    }

    public List<ParameterDTO> getParameterDTOS() {
        return parameterDTOS;
    }

    public void setParameterDTOS(List<ParameterDTO> parameterDTOS) {
        this.parameterDTOS = parameterDTOS;
    }

    public ModelDTO getModelDTO() {
        return modelDTO;
    }

    public void setModelDTO(ModelDTO modelDTO) {
        this.modelDTO = modelDTO;
    }

    public List<String> getFeatureColumnArr() {
        return featureColumnArr;
    }

    public void setFeatureColumnArr(List<String> featureColumnArr) {
        this.featureColumnArr = featureColumnArr;
    }

    public List<String> getOutputColumnArr() {
        return outputColumnArr;
    }

    public void setOutputColumnArr(List<String> outputColumnArr) {
        this.outputColumnArr = outputColumnArr;
    }
}