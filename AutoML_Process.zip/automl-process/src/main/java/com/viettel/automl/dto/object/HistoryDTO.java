package com.viettel.automl.dto.object;

import java.time.Instant;
import java.util.List;


public class HistoryDTO implements Comparable{
    private Long historyId;
    private Long modelId;
    private Long configFlowId;
    private String runNote;
    private String modelScore;
    private String task;
    private String inferTable;
    private String progress;
    private String currentTask;
    private Long currentStatus;
    private String currentRunNote;
    private Instant lastUpdateTime;
    private String location;
    private String schedule;
    private String interpreter;
    private Instant createTime;

    //dto only
    private ModelDTO modelDTO;
    private ConfigFlowDTO configFlowDTO;
    private ConnectionDTO connectionDTO;
    private ProjectDTO projectDTO;
    private List<ParameterInUseDTO> parameterInUseDTOS;
    private ModelTypeDTO modelTypeDTO;
    private NotebookDTO notebookDTO;
    private int[] tasks;

    //dto submited queues
    List<ProjectDTO> projectDTOS;

    public NotebookDTO getNotebookDTO() {
        return notebookDTO;
    }

    public void setNotebookDTO(NotebookDTO notebookDTO) {
        this.notebookDTO = notebookDTO;
    }

    public ProjectDTO getProjectDTO() {
        return projectDTO;
    }

    public void setProjectDTO(ProjectDTO projectDTO) {
        this.projectDTO = projectDTO;
    }

    public List<ParameterInUseDTO> getParameterInUseDTOS() {
        return parameterInUseDTOS;
    }

    public void setParameterInUseDTOS(List<ParameterInUseDTO> parameterInUseDTOS) {
        this.parameterInUseDTOS = parameterInUseDTOS;
    }

    public ModelTypeDTO getModelTypeDTO() {
        return modelTypeDTO;
    }

    public void setModelTypeDTO(ModelTypeDTO modelTypeDTO) {
        this.modelTypeDTO = modelTypeDTO;
    }

    public Long getHistoryId() {
        return historyId;
    }

    public void setHistoryId(Long historyId) {
        this.historyId = historyId;
    }

    public Long getModelId() {
        return modelId;
    }

    public void setModelId(Long modelId) {
        this.modelId = modelId;
    }

    public Long getConfigFlowId() {
        return configFlowId;
    }

    public void setConfigFlowId(Long configFlowId) {
        this.configFlowId = configFlowId;
    }

    public String getRunNote() {
        return runNote;
    }

    public void setRunNote(String runNote) {
        this.runNote = runNote;
    }

    public String getModelScore() {
        return modelScore;
    }

    public void setModelScore(String modelScore) {
        this.modelScore = modelScore;
    }

    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

    public String getInferTable() {
        return inferTable;
    }

    public void setInferTable(String inferTable) {
        this.inferTable = inferTable;
    }

    public String getProgress() {
        return progress;
    }

    public void setProgress(String progress) {
        this.progress = progress;
    }

    public String getCurrentTask() {
        return currentTask;
    }

    public void setCurrentTask(String currentTask) {
        this.currentTask = currentTask;
    }

    public Long getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(Long currentStatus) {
        this.currentStatus = currentStatus;
    }

    public String getCurrentRunNote() {
        return currentRunNote;
    }

    public void setCurrentRunNote(String currentRunNote) {
        this.currentRunNote = currentRunNote;
    }

    public Instant getLastUpdateTime() {
        return lastUpdateTime;
    }

    public void setLastUpdateTime(Instant lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getSchedule() {
        return schedule;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }

    public String getInterpreter() {
        return interpreter;
    }

    public void setInterpreter(String interpreter) {
        this.interpreter = interpreter;
    }

    public Instant getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Instant createTime) {
        this.createTime = createTime;
    }

    public ModelDTO getModelDTO() {
        return modelDTO;
    }

    public void setModelDTO(ModelDTO modelDTO) {
        this.modelDTO = modelDTO;
    }

    public ConfigFlowDTO getConfigFlowDTO() {
        return configFlowDTO;
    }

    public void setConfigFlowDTO(ConfigFlowDTO configFlowDTO) {
        this.configFlowDTO = configFlowDTO;
    }

    public ConnectionDTO getConnectionDTO() {
        return connectionDTO;
    }

    public void setConnectionDTO(ConnectionDTO connectionDTO) {
        this.connectionDTO = connectionDTO;
    }

    public int[] getTasks() {
        return tasks;
    }

    public void setTasks(int[] tasks) {
        this.tasks = tasks;
    }

    public List<ProjectDTO> getProjectDTOS() {
        return projectDTOS;
    }

    public void setProjectDTOS(List<ProjectDTO> projectDTOS) {
        this.projectDTOS = projectDTOS;
    }


    @Override
    public int compareTo(Object o) {
        return 0;
    }
}

