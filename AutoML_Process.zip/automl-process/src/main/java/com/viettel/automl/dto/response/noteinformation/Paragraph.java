package com.viettel.automl.dto.response.noteinformation;

public class Paragraph {
    private String id;
    private String text;
    private Result results;
    private String status;

    public Paragraph() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Result getResults() {
        return results;
    }

    public void setResults(Result results) {
        this.results = results;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "{" +
                "id='" + id + '\'' + "\n" +
                ", text='" + text + '\'' +"\n" +
                ", results='" + results + '\'' +"\n" +
                ", status='" + status + '\'' +"\n" +
                '}';
    }
}
