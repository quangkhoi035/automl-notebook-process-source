package com.viettel.automl.repository;

import com.viettel.automl.entities.ParameterInUseEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ParameterInUseRepository extends JpaRepository<ParameterInUseEntity, Long> {
    List<ParameterInUseEntity> findByConfigFlowId(Long configFlowId);
}
