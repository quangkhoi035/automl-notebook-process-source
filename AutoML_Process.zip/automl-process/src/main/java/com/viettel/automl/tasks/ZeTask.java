package com.viettel.automl.tasks;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.viettel.automl.config.ConfigInfo;
import com.viettel.automl.dto.object.NotebookDTO;
import com.viettel.automl.dto.response.UpdateParagraphResponse;
import com.viettel.automl.dto.response.noteinformation.NoteInformationResponse;
import com.viettel.automl.dto.response.noteinformation.Paragraph;
import com.viettel.automl.entities.HistoryEntity;
import com.viettel.automl.dto.object.HistoryDTO;
import com.viettel.automl.dto.response.CloneNotebookResponse;
import com.viettel.automl.dto.response.DeleteNotebookResponse;
import com.viettel.automl.dto.response.runparagraph.RunParagraphResponse;
import com.viettel.automl.entities.NotebookLogEntity;
import com.viettel.automl.repository.HistoryRepository;
import com.viettel.automl.repository.NotebookLogRepository;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.time.Instant;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("deprecation")
public class ZeTask implements Runnable {
    private final HistoryRepository historyRepository;
    private final NotebookLogRepository notebookLogRepository;

    private HistoryDTO dto;
    private String url;
    private String username;
    private String password;

    private String autoClassificationTempId;
    private String autoRegressionTempId;
    private String manualClassificationTempId;
    private String manualRegressionTempId;
    private String runExistingModelId;
    private String pathSaveNotebookClone;


    public ZeTask(HistoryRepository historyRepository, NotebookLogRepository notebookLogRepository, HistoryDTO dto, ConfigInfo configInfo) {
        this.historyRepository = historyRepository;
        this.notebookLogRepository = notebookLogRepository;
        this.dto = dto;
        this.url = configInfo.getUrl();
        this.username = configInfo.getUsername();
        this.password = configInfo.getPassword();

        this.autoClassificationTempId = configInfo.getAutoClassificationTempId();
        this.autoRegressionTempId = configInfo.getAutoRegressionTempId();
        this.manualClassificationTempId = configInfo.getManualClassificationTempId();
        this.manualRegressionTempId = configInfo.getManualRegressionTempId();
        this.runExistingModelId = configInfo.getRunExistingModelId();
        this.pathSaveNotebookClone = configInfo.getPathSaveNotebookClone();
    }

    @Override
    public void run() {
        NotebookLogEntity notebookLogEntity = new NotebookLogEntity();
        //Lấy ra Id của Notebook Template (Theo MODEL_MODE và ALGORITHM_TYPE và RUN_TYPE)
        String templateId = getTemplateIdZeppelin();

        //Login và lấy ra JSESSIONID
        DefaultHttpClient httpclient = new DefaultHttpClient();
        String jSessionId = zeppelinApiLogin(username, password, httpclient);

        //Clone Notebook template theo templateId và JSESSIONID ở trên, trả lại 1 đối tượng Response
        CloneNotebookResponse cloneNotebookResponse = cloneNotebook(templateId, jSessionId, httpclient);

        //Lay ra id notebook vua clone duoc
        String idNotebook = cloneNotebookResponse.getBody();

        // Cập nhật trạng thái History thành running
        updateCurrentStatusHistory(1l);

        //Run tat ca paragraph cua NoteBook vua clone
        NoteInformationResponse noteInformationResponse = getNotebookDetail(idNotebook, jSessionId, httpclient);
        boolean checkErrorRunParagraph = false;
        for (Paragraph paragraph : noteInformationResponse.getBody().getParagraphs()) {
            String interpreter = "%spark";
            String text = paragraph.getText();
            String[] list = text.split("\n");

            text = text.replace(list[0], interpreter);
            paragraph.setText(text);
//            updateParagraph(idNotebook, paragraph, jSessionId, httpclient);


            Instant start = Instant.now();
            RunParagraphResponse runParagraphResponse = runParagraphWithParam(idNotebook, paragraph.getId(), jSessionId,
                    httpclient, dto.getNotebookDTO());
            Instant end = Instant.now();

            notebookLogEntity.setProjectId(dto.getConfigFlowDTO().getProjectId());
            notebookLogEntity.setModelId(dto.getConfigFlowDTO().getModelId());
            notebookLogEntity.setHistoryId(dto.getHistoryId());
            notebookLogEntity.setUsername(dto.getConfigFlowDTO().getCreateUser());
            notebookLogEntity.setNotebookId(idNotebook);
            notebookLogEntity.setParagraphId(paragraph.getId());
            notebookLogEntity.setStatus(runParagraphResponse.getStatusCode() == 200 ? "done" : "error");
            //todo
            notebookLogEntity.setLogOutput("");
            if (runParagraphResponse.getBody().getMsg() != null && runParagraphResponse.getBody().getMsg().length != 0) {
                notebookLogEntity.setLogOutput(runParagraphResponse.getBody().getMsg()[0].getData());
            }

            notebookLogEntity.setStartTime(start);
            notebookLogEntity.setEndTime(end);
            notebookLogEntity.setLogId(null);

            boolean checkError = false;
            do {
                try {
                    notebookLogRepository.save(notebookLogEntity);
                } catch (Exception e){
                    checkError = true;
                    try {
                        Thread.sleep(10000);
                    } catch (InterruptedException interruptedException) {
                        interruptedException.printStackTrace();
                    }
                }
            } while (checkError);

            if (runParagraphResponse.getStatusCode() != 200) {
                checkErrorRunParagraph = true;
                break;
            }
        }
        if (checkErrorRunParagraph) {
            //Set status Error
            updateCurrentStatusHistory(5l);
        } else {
            //Set status Done
            updateCurrentStatusHistory(3l);
        }

//        In ra response get notebook info
//        System.out.println(getNotebookDetail(cloneNotebookResponse.getBody(), jSessionId, httpclient));

        //Xóa notebook sau khi chạy xong
//        DeleteNotebookResponse deleteNotebookResponse = deleteNotebook(cloneNotebookResponse.getBody(), jSessionId, httpclient);
//        System.out.println(deleteNotebookResponse.toString());
        httpclient.close();

    }

    //Get Notebook Id của Template mẫu
    private String getTemplateIdZeppelin() {
        if (dto.getConfigFlowDTO().getRunType().equals(0l)) {
            if (dto.getNotebookDTO().getMode().equals("auto") && dto.getNotebookDTO().getConfiguration().equals("classification")) {
                return autoClassificationTempId;
            } else if (dto.getNotebookDTO().getMode().equals("auto") && dto.getNotebookDTO().getConfiguration().equals("regression")) {
                return autoRegressionTempId;
            } else if (dto.getNotebookDTO().getMode().equals("manual") && dto.getNotebookDTO().getConfiguration().equals("classification")) {
                return manualClassificationTempId;
            } else {
                return manualRegressionTempId;
            }
        } else {
            return runExistingModelId;
        }
    }

    @Transactional
    void updateCurrentStatusHistory(Long newStatus) {
        Boolean checkError = false;
        do {
            try {
                HistoryEntity historyEntity = historyRepository.findById(this.dto.getHistoryId()).orElseThrow(
                        () -> new RuntimeException("Resource not found")
                );
                historyEntity.setCurrentStatus(newStatus);
                historyRepository.save(historyEntity);
                checkError = false;
            } catch(Exception e){
                checkError = true;
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException interruptedException) {
                    interruptedException.printStackTrace();
                }
            }
        } while (checkError);
    }

    private CloneNotebookResponse cloneNotebook(String templateId, String jSessionId, DefaultHttpClient httpclient) {
        CloneNotebookResponse cloneNotebookResponse = new CloneNotebookResponse();
        Instant timeCreate = Instant.now();
        HttpUriRequest request = RequestBuilder.create("POST")
                .setUri(url + "api/notebook/" + templateId)
                .setHeader("JSESSIONID", jSessionId)
                .setEntity(new StringEntity("{\"name\": \"" + pathSaveNotebookClone + dto.getConfigFlowDTO().getCreateUser() + "" + templateId + "" + timeCreate + "\"}", ContentType.APPLICATION_JSON))
                .build();

        try {
            CloseableHttpResponse response = httpclient.execute(request);
            String bodyResponse = parseBodyResponse(response);
            Gson gson = new GsonBuilder().create();
            cloneNotebookResponse = gson.fromJson(bodyResponse, CloneNotebookResponse.class);
            cloneNotebookResponse.setStatusCode(response.getStatusLine().getStatusCode());
            response.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return cloneNotebookResponse;
    }


    private DeleteNotebookResponse deleteNotebook(String templateId, String jSessionId, DefaultHttpClient httpclient) {
        DeleteNotebookResponse deleteNotebookResponse = new DeleteNotebookResponse();
        HttpUriRequest request = RequestBuilder.create("DELETE")
                .setUri(url + "api/notebook/" + templateId)
                .setHeader("JSESSIONID", jSessionId)
                .build();

        try {
            CloseableHttpResponse response = httpclient.execute(request);
            String bodyResponse = parseBodyResponse(response);
            Gson gson = new GsonBuilder().create();
            deleteNotebookResponse = gson.fromJson(bodyResponse, DeleteNotebookResponse.class);
            deleteNotebookResponse.setStatusCode(response.getStatusLine().getStatusCode());
            response.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return deleteNotebookResponse;
    }

    public RunParagraphResponse runParagraphWithParam(String notebookId, String paragraphId, String jSessionId, DefaultHttpClient httpclient,
                                                      NotebookDTO dto) {
        Gson gson = new Gson();
        String str = gson.toJson(dto);
        RunParagraphResponse runParagraphResponse = new RunParagraphResponse();
        HttpUriRequest request = RequestBuilder.create("POST")
                .setUri(url + "api/notebook/run/" + notebookId + "/" + paragraphId)
                .setHeader("JSESSIONID", jSessionId)
                .setEntity(new StringEntity("{\n" +
                        "  \"params\":" + str +
                        "}", ContentType.APPLICATION_JSON))
                .build();
        try {
            CloseableHttpResponse response = httpclient.execute(request);
            String bodyResponse = parseBodyResponse(response);
            gson = new GsonBuilder().create();
            runParagraphResponse = gson.fromJson(bodyResponse, RunParagraphResponse.class);
            runParagraphResponse.setStatusCode(response.getStatusLine().getStatusCode());
            response.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(str);
        return runParagraphResponse;
    }

    public UpdateParagraphResponse updateParagraph(String notebookId, Paragraph paragraph, String jSessionId, DefaultHttpClient httpclient) {
        Gson gson = new Gson();
        String str = gson.toJson(paragraph.getText());
        UpdateParagraphResponse updateParagraphResponse = new UpdateParagraphResponse();
        HttpUriRequest request = RequestBuilder.create("PUT")
                .setUri(url + "api/notebook/" + notebookId + "/paragraph/" + paragraph.getId())
                .setHeader("JSESSIONID", jSessionId)
                .setEntity(new StringEntity("{\n" +
                        "  \"text\":" + str +
                        "}", ContentType.APPLICATION_JSON))
                .build();
        try {
            CloseableHttpResponse response = httpclient.execute(request);
            String bodyResponse = parseBodyResponse(response);
            gson = new GsonBuilder().create();
            updateParagraphResponse = gson.fromJson(bodyResponse, UpdateParagraphResponse.class);
            updateParagraphResponse.setStatusCode(response.getStatusLine().getStatusCode());
            response.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return updateParagraphResponse;
    }

    public NoteInformationResponse getNotebookDetail(String notebookId, String jSessionId, DefaultHttpClient httpclient) {
        NoteInformationResponse noteInformationResponse = new NoteInformationResponse();
        HttpUriRequest request = RequestBuilder.create("GET")
                .setUri(url + "api/notebook/" + notebookId)
                .setHeader("JSESSIONID", jSessionId)
                .build();

        try {
            CloseableHttpResponse response = httpclient.execute(request);
            String bodyResponse = parseBodyResponse(response);
            Gson gson = new GsonBuilder().create();
            noteInformationResponse = gson.fromJson(bodyResponse, NoteInformationResponse.class);
            noteInformationResponse.setStatusCode(response.getStatusLine().getStatusCode());
            response.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return noteInformationResponse;
    }

    private String zeppelinApiLogin(String username, String password, DefaultHttpClient httpclient) {
        String urlLogin = url + "api/login";
        HttpPost postRequest = new HttpPost(urlLogin);
        List<NameValuePair> formparams = new ArrayList<>();
        formparams.add(new BasicNameValuePair("userName", username));
        formparams.add(new BasicNameValuePair("password", password));
        CloseableHttpResponse response = null;
        try {
            postRequest.setEntity(new UrlEncodedFormEntity(formparams, "UTF-8"));
            response = httpclient.execute(postRequest);
            response.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return parseSessionID(response);
    }

    private String parseSessionID(CloseableHttpResponse response) {
        String jSessionId = "";
        try {
            Header[] header = response.getAllHeaders();
            for (int i = 0; i < header.length; i++) {
                String value = header[i].getValue();
                if (value.contains("JSESSIONID")) {
                    int index = value.indexOf("JSESSIONID =");
                    int endIndex = value.indexOf(";", index);
                    String sessionID = value.substring(index + "JSESSIONID =".length(), endIndex);
                    jSessionId = sessionID;

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jSessionId;

    }

    private String parseBodyResponse(CloseableHttpResponse response) {
        String bodyJson = "";
        HttpEntity entity = response.getEntity();
        try {
            bodyJson = EntityUtils.toString(entity, "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return bodyJson;

    }
}