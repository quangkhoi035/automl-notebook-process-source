package com.viettel.automl.repository;

import com.viettel.automl.entities.ModelTypeEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ModelTypeRepository extends JpaRepository<ModelTypeEntity, Long> {
}
