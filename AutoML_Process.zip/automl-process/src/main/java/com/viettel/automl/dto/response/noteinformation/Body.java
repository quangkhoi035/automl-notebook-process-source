package com.viettel.automl.dto.response.noteinformation;

import java.util.List;

public class Body {
    private String id;
    private String name;
    private List<Paragraph> paragraphs;

    public List<Paragraph> getParagraphs() {
        return paragraphs;
    }

    public void setParagraphs(List<Paragraph> paragraphs) {
        this.paragraphs = paragraphs;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Body() {
    }

    @Override
    public String toString() {
        return "Body{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", paragraphs=" + paragraphs +
                '}';
    }
}
