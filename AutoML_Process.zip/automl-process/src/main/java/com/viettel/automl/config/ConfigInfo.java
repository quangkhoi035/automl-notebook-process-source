package com.viettel.automl.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ConfigInfo {
    @Value("${zeppelin.username}")
    private String username;
    @Value("${zeppelin.password}")
    private String password;
    @Value("${zeppelin.server}")
    private String url;

    @Value("${zeppelin.id.auto.classification}")
    private String autoClassificationTempId;
    @Value("${zeppelin.id.auto.regression}")
    private String autoRegressionTempId;
    @Value("${zeppelin.id.manual.classification}")
    private String manualClassificationTempId;
    @Value("${zeppelin.id.manual.regression}")
    private String manualRegressionTempId;
    @Value("${zeppelin.id.run.existing.model}")
    private String runExistingModelId;

    @Value("${zeppelin.path.save.notebook.clone}")
    private String pathSaveNotebookClone;


    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getUrl() {
        return url;
    }

    public String getAutoClassificationTempId() {
        return autoClassificationTempId;
    }

    public String getAutoRegressionTempId() {
        return autoRegressionTempId;
    }

    public String getManualClassificationTempId() {
        return manualClassificationTempId;
    }

    public String getManualRegressionTempId() {
        return manualRegressionTempId;
    }

    public String getRunExistingModelId() {
        return runExistingModelId;
    }

    public String getPathSaveNotebookClone() {
        return pathSaveNotebookClone;
    }
}
