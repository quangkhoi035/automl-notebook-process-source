//package com.viettel.automl.service.impl;
//
//import com.viettel.automl.entities.ConfigFlowEntity;
//import com.viettel.automl.entities.HistoryEntity;
//import com.viettel.automl.dto.object.NotebookDTO;
//import com.viettel.automl.entities.ModelEntity;
//import com.viettel.automl.entities.ProjectEntity;
//import com.viettel.automl.repository.ConfigFlowRepository;
//import com.viettel.automl.repository.HistoryRepository;
//import com.viettel.automl.repository.ModelRepository;
//import com.viettel.automl.repository.ProjectRepository;
//import com.viettel.automl.service.BaseService;
//import com.viettel.automl.service.NotebookService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//@Service
//public class NotebookServiceImpl extends BaseService implements NotebookService {
//    @Autowired
//    private HistoryRepository historyRepository;
//    @Autowired
//    private ModelRepository modelRepository;
//    @Autowired
//    private ConfigFlowRepository configFlowRepository;
//    @Autowired
//    private ProjectRepository projectRepository;
//
//    @Override
//    public NotebookDTO findByHistoryId(Long historyId) {
//       NotebookDTO notebookDTO = new NotebookDTO();
//
//        HistoryEntity historyEntity = historyRepository.findById(historyId)
//                .orElseThrow(() -> new RuntimeException("Resource not found"));
//
//        //Lấy ra thông tin model qua history và set thông tin vào notebookDTO
//        ModelEntity modelEntity = modelRepository.findById(historyEntity.getModelId())
//                .orElseThrow(() -> new RuntimeException("Resource not found"));
//
//        notebookDTO.setModelName(modelEntity.getModelName());
//        notebookDTO.setAutoTurningType(modelEntity.getAutoTurningType());
//        notebookDTO.setMetrics(modelEntity.getMetrics());
//        notebookDTO.setMaxTrialTime(modelEntity.getMaxTrialTime());
//        notebookDTO.setCheckpointStep(modelEntity.getCheckpointStep());
//        notebookDTO.setDataSubsamplingRadio(modelEntity.getDataSubsamplingRadio());
//        notebookDTO.setAllowPersist(modelEntity.getAllowPersist());
//        notebookDTO.setRatio(modelEntity.getRatio());
//        notebookDTO.setMaxDistinctValues(modelEntity.getMaxDistinctValues());
//        notebookDTO.setMaxMissingRatioAllow(modelEntity.getMaxMissingRatioAllow());
//        notebookDTO.setOptimizationAlgorithm(modelEntity.getOptimizationAlgorithm());
//
//        //Lấy ra thông tin ConfigFlow từ model ở trên
//        ConfigFlowEntity configFlowEntity = configFlowRepository.findByModelId(modelEntity.getModelId())
//                .orElseThrow(() -> new RuntimeException("Resource not found"));
//        notebookDTO.setTrainingTable(configFlowEntity.getTrainingTable());
//        notebookDTO.setValidationTable(configFlowEntity.getValidationTable());
//        notebookDTO.setTestingTable(configFlowEntity.getTestingTable());
//        notebookDTO.setLabelColumn(configFlowEntity.getLabelColumn());
//
//        //Lấy ra thông tin Project từ ConfigFlow ở trên
//        ProjectEntity projectEntity = projectRepository.findById(configFlowEntity.getProjectId())
//                .orElseThrow(() -> new RuntimeException("Resource not found"));
//        notebookDTO.setProjectName(projectEntity.getProjectName());
//
//        return notebookDTO;
//    }
//}
