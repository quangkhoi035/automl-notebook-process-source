package com.viettel.automl.dto.object;

public class ConnectionDTO {
}
