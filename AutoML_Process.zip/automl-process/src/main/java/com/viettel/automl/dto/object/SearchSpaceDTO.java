package com.viettel.automl.dto.object;

public class SearchSpaceDTO {
    private String type;
    private String featureSubsetStrategy;
    private String numTrees;
    private String maxDepth;
    private String maxBins;
    private String minInstancesPerNode;
    private String subsamplingRate;
    private String minInfoGain;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getFeatureSubsetStrategy() {
        return featureSubsetStrategy;
    }

    public void setFeatureSubsetStrategy(String featureSubsetStrategy) {
        this.featureSubsetStrategy = featureSubsetStrategy;
    }

    public String getNumTrees() {
        return numTrees;
    }

    public void setNumTrees(String numTrees) {
        this.numTrees = numTrees;
    }

    public String getMaxDepth() {
        return maxDepth;
    }

    public void setMaxDepth(String maxDepth) {
        this.maxDepth = maxDepth;
    }

    public String getMaxBins() {
        return maxBins;
    }

    public void setMaxBins(String maxBins) {
        this.maxBins = maxBins;
    }

    public String getMinInstancesPerNode() {
        return minInstancesPerNode;
    }

    public void setMinInstancesPerNode(String minInstancesPerNode) {
        this.minInstancesPerNode = minInstancesPerNode;
    }

    public String getSubsamplingRate() {
        return subsamplingRate;
    }

    public void setSubsamplingRate(String subsamplingRate) {
        this.subsamplingRate = subsamplingRate;
    }

    public String getMinInfoGain() {
        return minInfoGain;
    }

    public void setMinInfoGain(String minInfoGain) {
        this.minInfoGain = minInfoGain;
    }
}
