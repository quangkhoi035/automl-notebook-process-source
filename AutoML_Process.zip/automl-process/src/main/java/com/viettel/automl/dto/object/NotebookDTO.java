package com.viettel.automl.dto.object;

public class NotebookDTO {
    private String project;
    private String model_name;
    private String train_table;
    private String valid_table;
    private String test_table;
    private String features_columns;
    private String label_column;
    private String mode;
    private String configuration;
    private String auto_tuning_type;
    private Float feature_max_missing_ratio_allow;
    private Long feature_max_distinct_values;
    private String metric;
    private Long max_trials;
    private Long checkpoint_steps;
    private Float data_subsampling_ratio;
    private Boolean allow_persist;
    private String search_algorithm;
    private String search_space;
    private Float train_ratio;
    private Long k_folds;

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public String getModel_name() {
        return model_name;
    }

    public void setModel_name(String model_name) {
        this.model_name = model_name;
    }

    public String getTrain_table() {
        return train_table;
    }

    public void setTrain_table(String train_table) {
        this.train_table = train_table;
    }

    public String getValid_table() {
        return valid_table;
    }

    public void setValid_table(String valid_table) {
        this.valid_table = valid_table;
    }

    public String getTest_table() {
        return test_table;
    }

    public void setTest_table(String test_table) {
        this.test_table = test_table;
    }

    public String getFeatures_columns() {
        return features_columns;
    }

    public void setFeatures_columns(String features_columns) {
        this.features_columns = features_columns;
    }

    public String getLabel_column() {
        return label_column;
    }

    public void setLabel_column(String label_column) {
        this.label_column = label_column;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getConfiguration() {
        return configuration;
    }

    public void setConfiguration(String configuration) {
        this.configuration = configuration;
    }

    public String getAuto_tuning_type() {
        return auto_tuning_type;
    }

    public void setAuto_tuning_type(String auto_tuning_type) {
        this.auto_tuning_type = auto_tuning_type;
    }

    public Float getFeature_max_missing_ratio_allow() {
        return feature_max_missing_ratio_allow;
    }

    public void setFeature_max_missing_ratio_allow(Float feature_max_missing_ratio_allow) {
        this.feature_max_missing_ratio_allow = feature_max_missing_ratio_allow;
    }

    public Long getFeature_max_distinct_values() {
        return feature_max_distinct_values;
    }

    public void setFeature_max_distinct_values(Long feature_max_distinct_values) {
        this.feature_max_distinct_values = feature_max_distinct_values;
    }

    public String getMetric() {
        return metric;
    }

    public void setMetric(String metric) {
        this.metric = metric;
    }

    public Long getMax_trials() {
        return max_trials;
    }

    public void setMax_trials(Long max_trials) {
        this.max_trials = max_trials;
    }

    public Long getCheckpoint_steps() {
        return checkpoint_steps;
    }

    public void setCheckpoint_steps(Long checkpoint_steps) {
        this.checkpoint_steps = checkpoint_steps;
    }

    public Float getData_subsampling_ratio() {
        return data_subsampling_ratio;
    }

    public void setData_subsampling_ratio(Float data_subsampling_ratio) {
        this.data_subsampling_ratio = data_subsampling_ratio;
    }

    public Boolean getAllow_persist() {
        return allow_persist;
    }

    public void setAllow_persist(Boolean allow_persist) {
        this.allow_persist = allow_persist;
    }

    public String getSearch_algorithm() {
        return search_algorithm;
    }

    public void setSearch_algorithm(String search_algorithm) {
        this.search_algorithm = search_algorithm;
    }

    public String getSearch_space() {
        return search_space;
    }

    public void setSearch_space(String search_space) {
        this.search_space = search_space;
    }

    public Float getTrain_ratio() {
        return train_ratio;
    }

    public void setTrain_ratio(Float train_ratio) {
        this.train_ratio = train_ratio;
    }

    public Long getK_folds() {
        return k_folds;
    }

    public void setK_folds(Long k_folds) {
        this.k_folds = k_folds;
    }
}
